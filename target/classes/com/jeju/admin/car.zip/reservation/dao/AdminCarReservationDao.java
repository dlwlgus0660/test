package com.jeju.admin.car.reservation.dao;

import java.util.List;

import com.jeju.admin.car.reservation.vo.AdminCarReservationVO;

public interface AdminCarReservationDao {
	
	public List<AdminCarReservationVO> carResList();
}
