package com.jeju.admin.car.reservation.service;

import java.util.List;

import com.jeju.admin.car.reservation.vo.AdminCarReservationVO;

public interface AdminCarReservationService {
	
	public List<AdminCarReservationVO> carResList();
	
}
